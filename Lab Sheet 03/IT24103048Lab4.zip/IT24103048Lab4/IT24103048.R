setwd("C:\\Users\\IT24103048\\Desktop")

#01
branch_data<-read.table("Exercise.txt",header = TRUE,sep = ",")
fix(branch_data)

#02
str(branch_data)
fix(branch_data)
attach(branch_data)

#03
boxplot (branch_data$sales_X1, main = "Boxplot of sales", ylab = "Sales(X1)",col = "Tightblue",boder = "Darkblue")
grid()

#04
summary(branch_data$Advertising_X2)
IQR_advert<- IQR(branch_data$Advertising_X2)
print(paste("IQR for Advertising:" , IQR_advert))

#05
find_outliers <- function(x){
  q1 <- quantile(x, 0.25)
  q3 <- quantile(x, 0.75)
  iqr <- q3 - q1
  lower_bound <- q1 -1.5 * iqr
  upper_bound <- q3 -1.5 * iqr
  outliers <- x[x < lower_bound | x > upper_bound]
  if(length(outliers) == 0) return ("No outliers") else return(outliers)
}

years_outliers <- find_outliers(branch_data$Years_X3)
print("outliers in years:")
print(years_outliers)